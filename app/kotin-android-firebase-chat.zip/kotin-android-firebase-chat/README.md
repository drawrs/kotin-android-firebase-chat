# Kotlin Chat App Firebase 2019

I have deleted google-services.json. Add yours
<br><b> Change Authorization:key with your key from firebase project</b>

<br>Implementation Guide 
<br>1 - Project
<br>1 - Open the Project in your android studio;
<br>2 - *IMPORTANT* Change the Package Name. (https://stackoverflow.com/questions/16804093/android-studio-rename-package)

<br>2 - Firebase Panel
<br>1 - Create Firebase Project (https://console.firebase.google.com/);
<br>2 - import the file google-service.json into your project

Thanks @KODDevYouTube
