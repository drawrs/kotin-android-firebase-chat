package com.intoverflown.samplechatapp.model

data class Chatlist(var id: String = "")