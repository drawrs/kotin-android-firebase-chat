package com.intoverflown.samplechatapp.notifications

data class Token(var token: String? = null)